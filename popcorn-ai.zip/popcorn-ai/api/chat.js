export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) return res.status(500).json({ error: 'Server is missing OPENROUTER_API_KEY. Add it in your deployment environment settings.' });
  try {
    const { messages } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0) return res.status(400).json({ error: 'Please provide chat messages.' });
    const safeMessages = messages.slice(-30).map(m => ({ role: ['user','assistant','system'].includes(m.role) ? m.role : 'user', content: String(m.content || '').slice(0, 12000) }));
    const upstream = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST', headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json', 'HTTP-Referer': process.env.APP_URL || 'https://popcorn-ai.vercel.app', 'X-Title': 'Popcorn AI' },
      body: JSON.stringify({ model: 'openrouter/free', messages: [{ role: 'system', content: 'You are Popcorn AI, a helpful, friendly assistant. Be accurate, clear, and concise. If unsure, say so.' }, ...safeMessages], stream: false })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: data?.error?.message || 'AI provider request failed.' });
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'The AI returned an empty response. Try again.' });
    return res.status(200).json({ reply });
  } catch (e) { return res.status(500).json({ error: 'Could not reach the AI service. Check your connection and try again.' }); }
}
